#Requires -RunAsAdministrator

./loki.exe -s 60000 $args --csv --allhds
